---
name: Bug report
about: Report a problem with bootstrap, generated files, or package behavior
title: "[Bug]: "
labels: bug
assignees: ""
---

## What happened?

## Expected behavior

## Reproduction steps

## Environment

- OS:
- Node version:
- Package version:
- Command:

## Relevant output

```text

```
