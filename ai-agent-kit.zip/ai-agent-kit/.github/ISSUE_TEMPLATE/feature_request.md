---
name: Feature request
about: Suggest an improvement for AI Agent Kit
title: "[Feature]: "
labels: enhancement
assignees: ""
---

## Problem

## Proposed solution

## Who benefits?

- [ ] Engineering managers
- [ ] Developers
- [ ] QA
- [ ] Security/compliance
- [ ] New team members

## Safety considerations

Does this change affect bootstrap's local-only behavior?
