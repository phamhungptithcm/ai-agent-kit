## Summary

## Validation

- [ ] `npm run check`
- [ ] `npm run release:dry-run` reviewed when package contents changed

## Safety Review

- [ ] Bootstrap remains local only
- [ ] No remote Git, ticketing, deployment, or source-code modification behavior added
- [ ] No customer names, secrets, internal URLs, or environment-specific paths added
