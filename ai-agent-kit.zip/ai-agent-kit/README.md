# @hunpeolabs/ai-agent-kit

[![npm version](https://img.shields.io/npm/v/@hunpeolabs/ai-agent-kit.svg)](https://www.npmjs.com/package/@hunpeolabs/ai-agent-kit)
[![npm downloads](https://img.shields.io/npm/dm/@hunpeolabs/ai-agent-kit.svg)](https://www.npmjs.com/package/@hunpeolabs/ai-agent-kit)
[![CI](https://github.com/hunpeolabs/ai-agent-kit/actions/workflows/npm-publish.yml/badge.svg)](https://github.com/hunpeolabs/ai-agent-kit/actions/workflows/npm-publish.yml)

Bootstrap a repository-scoped AI agent operating system for Claude Code and OpenAI Codex, with an adapter strategy for other AI coding agents.

It installs shared `.ai/` policy, Claude/Codex adapter files, role skills, safety gates, review handoff templates, prompt catalogs, and local repository-intelligence checks powered by CodeGraph and CocoIndex.

```bash
npx --yes @hunpeolabs/ai-agent-kit@latest bootstrap
```

## Why Teams Use It

Most AI coding setups start with a prompt file. This kit gives a team an operating model:

- One shared source of truth in `.ai/` for workflow, risk, security, testing, delivery evidence, and approval gates.
- Claude Code and Codex receive the same team policy through generated platform adapters.
- The adapter model is designed to expand to other agents without forking team policy.
- Every task starts with repository intelligence: CodeGraph for structure and CocoIndex for semantic code/document retrieval.
- Existing-system changes stop at an impact plan until a human explicitly approves implementation.
- Bootstrap is local only: no branch, commit, push, MR, Jira update, deployment, or application source edit.

## How It Works

AI Agent Kit turns a target repository into a governed AI-agent workspace without changing application source code.

```mermaid
flowchart LR
  Dev[Developer] --> CLI[npx ai-agent-kit bootstrap]
  CLI --> Repo[Target Git repository]

  Repo --> AI[.ai shared policy]
  Repo --> Prompts[.ai/PROMPTS.md]
  Repo --> Adapters[Claude and Codex adapters]
  Repo --> Local[.ai-agent-kit local metadata]

  AI --> Workflows[Workflows and skills]
  AI --> Guards[Safety and approval gates]
  AI --> Quality[Quality gates and output contract]
  AI --> Memory[Memory governance]

  Prompts --> Agent[AI agent]
  Adapters --> Agent
  Agent --> Evidence[Plans, reviews, fixes, validation evidence]
  Evidence --> Human[Human review, commit, PR/MR, Jira, deploy]
```

What bootstrap affects in a project:

| Area | Purpose |
| --- | --- |
| `.ai/` | Shared policy, prompt catalog, workflows, skills, guards, scripts, evals, quality gates, and memory governance. |
| `AGENTS.md`, `CLAUDE.md` | Route Codex and Claude Code to the same team rules. |
| `.codex/`, `.claude/`, `.agents/` | Platform adapters, roles, generated skills, hooks, and command rules. |
| `.mcp.json` | Local repository-intelligence tool wiring. |
| `.ai-agent-kit/` | Local backups, install report, and copy-ready handoff drafts. |
| `.gitignore` | Managed ignores for local AI-agent caches and backups. |

It does not edit application source, stage files, commit, push, open PRs/MRs, update Jira, or deploy.

## Prompt-To-Project Loop

Developers start from a purpose-named prompt, not a blank chat. The agent then follows repository policy before producing output that can safely flow back into the project.

```mermaid
sequenceDiagram
  participant Dev as Developer
  participant Prompt as Prompt Catalog
  participant Agent as AI Agent
  participant RI as CodeGraph + CocoIndex
  participant Policy as .ai Policy
  participant Project as Project Files
  participant Review as Human Review

  Dev->>Prompt: Choose start-task, plan-change, fix-bug, review-pr, etc.
  Prompt->>Agent: Prompt plus ticket, diff, bug, or incident context
  Agent->>RI: Run repository intelligence gate
  RI-->>Agent: Structural impact and semantic evidence
  Agent->>Policy: Load workflow, risk, guards, quality gates, output contract
  Agent->>Project: Read relevant source, tests, docs, and config
  Agent-->>Dev: Facts, assumptions, risk, plan, findings, or implementation

  alt Existing-system change
    Agent-->>Review: Change-impact plan and approved scope request
    Review-->>Agent: Explicit approval
    Agent->>Project: Implement only approved scope
  end

  Agent-->>Dev: Validation results, quality gates, handoff text, memory candidates
  Dev->>Project: Manual review, commit, PR/MR, Jira, deploy
```

See the full design walkthrough in [High-Level Design](docs/HIGH_LEVEL_DESIGN.md).

## Agent Ecosystem And Roadmap

AI Agent Kit ships concrete adapters for Claude Code and OpenAI Codex today. The broader model is adapter-based: keep `.ai/` as the source of truth, then generate thin adapters for each agent surface.

Common adapter targets teams ask about:

| Agent | Planned Adapter Surface |
| --- | --- |
| GitHub Copilot coding agent | Copilot repository instructions, path-specific instructions, `AGENTS.md`. |
| Cursor | Cursor Rules, `AGENTS.md`, prompt catalog, MCP config. |
| Windsurf / Devin Desktop Cascade | `.windsurf/skills/`, `AGENTS.md`, `.agents/skills/`. |
| Gemini CLI / Gemini Code Assist | `GEMINI.md`, `.mcp.json`, prompt catalog. |
| Amazon Q Developer | `.amazonq/rules/*.md`, prompt catalog, validation commands. |
| JetBrains Junie | `AGENTS.md`, `.junie/AGENTS.md`, guidelines, skills. |
| Cline, Devin, Aider, Continue | Agent-specific instructions, playbooks/rules/config, prompt catalog, quality gates. |

See [Agent Adapter Strategy](docs/AGENT_ADAPTER_STRATEGY.md) for the support model, current status, and expansion order.

## Who It Helps

| Audience | What they get |
| --- | --- |
| Engineering managers | Consistent AI-assisted delivery rules, safer delegation, clearer review evidence. |
| Developers | Ready-to-use Claude/Codex skills for planning, implementation, bug fixes, reviews, incidents, and docs. |
| QA | Risk-aware test strategy, validation evidence, regression thinking, and demo artifact templates. |
| HR and onboarding leads | A repeatable team working model that new engineers can install into a repository in one command. |

## Quick Start

Run inside the target Git repository:

```bash
npx --yes @hunpeolabs/ai-agent-kit@latest bootstrap
```

After bootstrap, open `.ai/PROMPTS.md` in the target repository or print copy-ready prompts:

```bash
npx --yes @hunpeolabs/ai-agent-kit@latest prompts
npx --yes @hunpeolabs/ai-agent-kit@latest prompt start-task
npx --yes @hunpeolabs/ai-agent-kit@latest prompt plan-change
```

Preview the planned files without writing anything:

```bash
npx --yes @hunpeolabs/ai-agent-kit@latest bootstrap --dry-run
```

Install only one platform adapter:

```bash
npx --yes @hunpeolabs/ai-agent-kit@latest bootstrap --claude-only
npx --yes @hunpeolabs/ai-agent-kit@latest bootstrap --codex-only
```

## What Gets Installed

- `.ai/`: shared policy, workflows, skills source, guards, scripts, prompts, templates, and evals.
- `.claude/` and `CLAUDE.md`: Claude Code adapter files.
- `.codex/`, `.agents/`, and `AGENTS.md`: Codex adapter files and generated skills.
- `AI_AGENT_TEAM_GUIDE.md`: human-readable operating guide for the team.
- `.ai-agent-kit/`: local installation metadata, backups, transaction reports, and copy-ready review/Jira output.

The bundled scaffold lives under `assets/enterprise-ai-agent-os/`.

## Safety Model

The bootstrap command detects the current Git repository, safely merges managed sections, installs or refreshes AI-agent config, verifies CodeGraph and CocoIndex, refreshes indexes when possible, validates the setup, prints the local diff, and stops.

It does not:

- stage files
- create commits
- create branches
- push to remotes
- create merge requests
- call GitLab, GitHub, Jira, or deployment APIs
- modify application source code

## Local Development

```bash
npm ci
npm run check
npm run release:dry-run
```

Useful individual commands:

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

## Publishing

The GitHub Actions workflow in `.github/workflows/npm-publish.yml` validates pull requests and main-branch pushes, then publishes to npm when a `v*.*.*` tag is pushed or when the workflow is manually dispatched with `publish=true`.

The publish job reads `NPM_TOKEN` from GitHub Actions secrets first, with repository variables as a fallback. Prefer a GitHub secret for real npm tokens.

Before a public launch, choose the final repository URL and license. This package currently keeps `UNLICENSED` intentionally so the owner can make that legal decision explicitly.

## Learn More

- [High-level design](docs/HIGH_LEVEL_DESIGN.md)
- [Agent adapter strategy](docs/AGENT_ADAPTER_STRATEGY.md)
- [Adoption guide](docs/ADOPTION_GUIDE.md)
- [Public launch checklist](docs/PUBLIC_LAUNCH_CHECKLIST.md)
- [Security policy](SECURITY.md)
- [Changelog](CHANGELOG.md)
