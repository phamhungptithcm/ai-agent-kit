## Summary

## Business Outcome

## Current Behavior / Root Cause

## Design Rationale

## Files Changed

## Behavioral Changes

## Tests Added

## Commands Executed And Results

## Security Impact

## Data And Migration Impact

## Performance And Concurrency Impact

## Observability Impact

## Deployment Notes

## Rollback Plan

## Remaining Risks And Unverified Assumptions
