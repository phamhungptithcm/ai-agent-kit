# Agent Roles

All repository-facing roles must use the `repository-intelligence` skill before brainstorming, planning, impact analysis, review, QA analysis, documentation analysis, or implementation.

The Team Lead Orchestrator owns the shared repository intelligence brief and must populate `.ai/templates/repository-intelligence-brief.md` before assigning specialists.

Specialist roles reuse the shared brief and query CodeGraph or CocoIndex only for role-specific gaps:

- Team Lead Orchestrator
- Domain Analyst
- Impact Explorer
- Solution Architect
- Tech Lead
- Implementation Engineer
- Database/Data Engineer
- Integration Engineer
- UI/UX Lead
- QA Lead
- Security Reviewer
- SRE/Release Engineer
- Documentation Delivery Agent
- Independent Code Reviewer
- Module Context Owner
- Memory Approver
- Skill Maintainer
- Quarterly Review

CodeGraph is required for structural evidence and impact. CocoIndex is required for semantic, requirements, specification, runbook, test, and documentation evidence. Source code remains authoritative for critical behavior.

## Governance Roles

- Module Context Owner verifies module-scoped memory, context docs, and ownership facts against current source and team ownership.
- Memory Approver approves, rejects, supersedes, or marks memory entries stale under `.ai/core/memory-policy.md`.
- Skill Maintainer keeps `.ai/skills-src/`, platform adapters, prompts, and validators aligned with approved policy.
- Quarterly Review performs the scheduled stale-memory and policy drift review, then records required follow-up.
