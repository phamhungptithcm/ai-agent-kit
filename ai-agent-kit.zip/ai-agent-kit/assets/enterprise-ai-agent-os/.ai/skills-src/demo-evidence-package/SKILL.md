---
name: demo-evidence-package
description: Generate or outline demo evidence for UAT, customer review, or operational handoff. Use when a change needs PPTX/XLSX artifacts and manual screenshot placeholders.
---

# Demo Evidence Package

Before creating demo evidence, run the Repository Intelligence Gate when the demo summarizes repository behavior. Use CodeGraph/CocoIndex evidence for impacted components, validation, docs/specs/diagrams, and screenshot placeholder scope.

## Required Artifacts

- PPTX deck with Jira key, change title, problem/RCA or planned-change rationale, solution, validation, screenshot placeholders, deployment, rollback, and risks.
- XLSX workbook with summary, acceptance criteria, validation, artifacts, and screenshot placeholder worksheets.
- Markdown screenshot placeholder table with exact capture instructions.

## Rules

- Screenshots are manual placeholders unless a human supplies or captures them.
- Do not fabricate screenshots, demo results, or external links.
- Report exact output paths and validation result, or report blocked generation with complete source outlines.
