---
name: start-task
description: Convert an incomplete or risky request into an engineering task contract before editing. Use for ambiguous, broad, high-risk, or discovery-heavy work; do not use for tiny well-scoped edits.
---

# Start Task

Use this skill to analyze before editing.

First run the Repository Intelligence Gate and use the `repository-intelligence` skill. Create a shared repository intelligence brief before assigning subagents or producing a plan.

## Required Analysis

1. Restate the business outcome.
2. Query CodeGraph for likely modules, entry points, callers/callees, and impact.
3. Query CocoIndex for related terminology, requirements, specs, docs, tests, and similar implementations.
4. Inspect only relevant code, tests, configuration, and documentation needed to verify indexed evidence.
5. Trace the current execution path.
6. Separate indexed facts, source-code verified facts, and assumptions.
7. Identify impacted modules, contracts, data, dependencies, and operators.
8. Classify risk using `.ai/core/risk-model.md`.
9. Propose the smallest safe change.
10. Identify change area boundary, impact boundary, and areas requiring developer review before touching.
11. Identify tests, validation evidence, quality gates, documentation, specification, diagram, PR/MR, Jira, deployment, rollback, and memory-governance impacts.

## Stop Conditions

Stop before editing when the task touches existing application code, database behavior, runtime config, infrastructure, public contracts, or behavior-changing tests and explicit plan approval is missing. Also stop when the task is high or critical risk, when acceptance criteria conflict with security policy, or when the real execution path cannot be identified.

## Output

Return understanding, current flow, impacted components, facts vs assumptions, risk classification, smallest safe change, expected files/classes/functions, change boundary, impact and regression analysis, test strategy, quality-gate expectations, documentation/specification/diagram impact, deployment and rollback considerations, memory-governance impact, execution plan, and explicit approval request when needed.
