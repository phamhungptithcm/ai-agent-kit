---
name: start-task
description: Intake, classify, analyze, and prepare any repository engineering request before implementation. Produce an engineering task contract, determine required downstream workflows, and stop unsafe work before code is modified.
---

# Start Task

## Purpose

Start Task is the mandatory entry point for all engineering work.

It converts ambiguous requests into a verified engineering task contract.

Objectives:

- understand the business outcome
- understand the existing system
- identify risks
- determine scope
- identify required engineering workflows
- determine whether implementation is allowed

No production code should be edited before this workflow completes.

---

# Phase 1 — Repository Intelligence

Execute the Repository Intelligence Gate.

Run:

```
repository-intelligence
```

Generate the shared Repository Intelligence Brief.

---

# Phase 2 — Understand the Request

Determine:

- business objective
- requested capability
- expected outcome
- acceptance criteria
- constraints
- urgency

If acceptance criteria are missing:

Stop and request clarification.

---

# Phase 3 — Classify the Task

Automatically classify.

Possible categories:

- Bug Fix
- Feature
- Enhancement
- Refactor
- Performance
- Security
- Database
- API
- Infrastructure
- DevOps
- Production Incident
- Documentation
- Design
- Research
- Investigation
- Spike

A task may belong to multiple categories.

---

# Phase 4 — Repository Discovery

Using Repository Intelligence determine:

- modules
- entry points
- services
- APIs
- repositories
- persistence
- integrations
- documentation
- tests
- deployment

Identify the execution path.

---

# Phase 5 — Evidence Collection

Separate information into:

## Repository Evidence

## Source-Code Evidence

## Runtime Evidence

## Assumptions

## Unknowns

Never mix assumptions with facts.

---

# Phase 6 — Impact Analysis

Identify:

- changed modules
- callers
- consumers
- APIs
- databases
- infrastructure
- documentation
- diagrams
- tests

Determine blast radius.

---

# Phase 7 — Risk Assessment

Classify using:

```
.ai/core/risk-model.md
```

Determine:

- Low
- Medium
- High
- Critical

Identify required human approval.

---

# Phase 8 — Quality Discovery

Automatically determine:

- language
- framework
- runtime
- platform
- domain

Load:

```
.ai/core/code-quality-intelligence.md
```

Identify all applicable quality profiles.

---

# Phase 9 — Required Skills

Automatically determine downstream skills.

Examples:

Feature →

- implement-feature
- code-review
- delivery-documentation

Bug →

- fix-bug
- code-review
- jira-completion-package

Database →

- database-change

Architecture →

- design-document

Production →

- production-incident

Delivery →

- delivery-documentation
- demo-evidence-package

Multiple skills may be required.

---

# Phase 10 — Engineering Plan

Recommend:

- smallest safe change
- implementation boundary
- protected files
- required approvals
- implementation order

---

# Phase 11 — Validation Plan

Identify:

- tests
- quality gates
- code review
- documentation
- diagrams
- deployment
- rollback

---

# Phase 12 — Decision Gate

Implementation is allowed only if:

✓ Repository Intelligence completed

✓ Acceptance criteria understood

✓ Current execution path verified

✓ Impact understood

✓ Risk acceptable

✓ Required approvals exist

Otherwise stop.

---

# Deliverables

Produce:

1. Executive Summary
2. Repository Intelligence Summary
3. Business Objective
4. Current Flow
5. Task Classification
6. Repository Evidence
7. Source-Code Evidence
8. Assumptions
9. Unknowns
10. Impact Analysis
11. Risk Assessment
12. Required Skills
13. Recommended Plan
14. Validation Plan
15. Deployment Considerations
16. Rollback Considerations
17. Required Approvals
18. Execution Roadmap

Never begin implementation until the Decision Gate succeeds.