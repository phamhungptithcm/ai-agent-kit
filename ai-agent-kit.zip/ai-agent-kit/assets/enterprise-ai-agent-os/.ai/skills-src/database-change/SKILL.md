---
name: database-change
description: Analyze and implement database changes safely. Use for SQL, migrations, schema changes, query performance, data migration, diff scripts, and datafix procedures.
---

# Database Change

Before database analysis, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Use CodeGraph for data-access paths and consumers, and CocoIndex for schema docs, migrations, datafix procedures, and runbooks.

## Required Analysis

1. Identify affected tables, views, procedures, jobs, indexes, and consumers.
2. Classify data sensitivity and business criticality.
3. Review locking, transaction, query-plan, index, rollout, compatibility, and rollback risk.
4. Determine validation queries and expected row counts where applicable.
5. Coordinate with existing Jenkins/GitLab database diff-script flows.

## Rules

- Avoid `SELECT *` in production queries.
- Use bounded queries and pagination.
- Do not call `repository.save()` inside large loops.
- Use batch update, bulk persistence, or set-based SQL for large transactions.
- If loop persistence is unavoidable, document transaction size, flush/clear behavior, locking risk, retry/idempotency behavior, and approval evidence.
- Prefer backward-compatible migrations.
- Separate schema migration from destructive cleanup.
- Never run production datafixes autonomously.
- Require explicit approval for destructive changes or production datafixes.

## Output

Report migration strategy, deployment sequence, validation, rollback, security/data impact, performance/concurrency impact, and unresolved assumptions.
