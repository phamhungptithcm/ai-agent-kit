---
name: architecture-diagrams
description: Create or update text-based diagrams for architecture, sequence, component, class, state, data-flow, and ER views. Use when behavior or design changes affect diagrams.
---

# Architecture Diagrams

Before diagram analysis, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Base diagrams on CodeGraph structure, CocoIndex docs/specs, and source-code verification.

Use Mermaid or another repository-approved text-based source format.

## Choose Diagram Type

- Sequence for interactions, retries, async handoffs, and error paths.
- Component for module/service boundaries and dependencies.
- Class for important object relationships.
- State for lifecycle/status transitions.
- Data-flow for sensitive, financial, or operational data movement.
- ER for schema/entity relationships.

## Rules

- Keep diagram source reviewable as text.
- Link diagrams from authoritative documentation.
- Do not invent unverified production topology, ownership, or integrations.
- Provide a specific no-change rationale if no diagram update is required.
