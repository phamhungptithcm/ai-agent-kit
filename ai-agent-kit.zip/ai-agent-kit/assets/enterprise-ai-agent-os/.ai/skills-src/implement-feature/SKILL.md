---
name: implement-feature
description: Implement an approved feature using the smallest safe change. Use when scope and acceptance criteria are clear; do not use to expand scope or skip design for high-risk work.
---

# Implement Feature

Before implementation, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Existing-system implementation requires indexed analysis, a reviewed plan, explicit approval evidence, and post-change index refresh.

## Required Analysis

1. Confirm the business capability, acceptance criteria, and owning module.
2. Use CodeGraph for expected files/functions and impact.
3. Use CocoIndex for similar implementations, docs/specs, tests, and local patterns.
4. Identify contracts, authorization, data ownership, compatibility, and operational impact.
5. Classify risk and required human gates.
6. For existing-system changes, verify an approved change-impact plan before editing protected files.

## Implementation Rules

- Preserve existing behavior unless explicitly changed.
- Keep edits local to the approved behavior.
- Stop for a delta-impact plan and renewed approval when implementation requires material scope or design deviation.
- Do not add dependencies without documented rationale and review.
- Validate boundary input and keep errors stable.
- Protect authentication, authorization, PII, transactions, and audit behavior.
- Do not call `repository.save()` inside large loops; use batch or bulk persistence unless an approved exception documents transaction size, flush/clear behavior, locking risk, and retry/idempotency behavior.
- Add or update tests that demonstrate expected behavior.
- Add observability for production-significant behavior.
- Update docs/specs/diagrams or provide a specific no-change rationale.

## Completion

Report approved-plan compliance, CodeGraph/CocoIndex refresh status, design rationale, files changed, behavior changed, tests and command results, quality gates from `.ai/core/quality-gates.md`, security/data/performance/observability impact, docs/specs/diagrams, PR/MR or Jira evidence when applicable, memory candidates under `.ai/core/memory-policy.md` or `None`, deployment notes, rollback, and remaining risk.
