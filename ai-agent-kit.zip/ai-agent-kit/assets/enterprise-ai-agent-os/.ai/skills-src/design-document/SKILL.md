---
name: design-document
description: Produce an RFC or design document for cross-module, complex, or high-risk changes. Use before implementation when architecture, data, API, security, rollout, or rollback needs review.
---

# Design Document

Before drafting, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Base current state, options, and impacts on CodeGraph, CocoIndex, and source-code verification.

Include:

- Context
- Goals
- Non-goals
- Current state
- Options considered
- Decision
- Architecture
- Data model
- APIs and contracts
- Security and privacy
- Performance and scalability
- Observability
- Rollout
- Rollback
- Testing
- Risks
- Unresolved questions

Use observed repository facts and mark unknowns with `TODO(owner): ...`. Do not invent business rules, ownership, production topology, or data semantics.
