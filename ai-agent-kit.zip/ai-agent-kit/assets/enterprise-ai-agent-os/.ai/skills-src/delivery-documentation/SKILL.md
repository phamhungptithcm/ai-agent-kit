---
name: delivery-documentation
description: Prepare a complete delivery package by synchronizing implementation evidence, documentation, architecture, testing, quality gates, release readiness, and work-item traceability. Use immediately before pull request creation, merge approval, or implementation handoff.
---

# Delivery Documentation

## Purpose

Prepare a complete, evidence-based delivery package.

Ensure implementation, documentation, testing, architecture, and operational artifacts remain synchronized.

Never fabricate implementation evidence.

---

# Repository Intelligence Gate (Required)

Before preparing delivery artifacts:

1. Execute the Repository Intelligence Gate.
2. Use the `repository-intelligence` skill.
3. Collect repository evidence from:

- CodeGraph
- CocoIndex
- ADRs
- RFCs
- DESIGN.md
- ARCHITECTURE.md
- Existing diagrams
- Existing PR templates
- Existing runbooks
- Existing work items
- Quality reports
- Test reports

Use:

- CodeGraph to identify changed symbols, dependency impact, and affected modules.
- CocoIndex to locate documentation, specifications, diagrams, architectural decisions, and operational guidance.

---

# Delivery Discovery

Determine:

- implementation scope
- changed files
- changed modules
- affected services
- APIs
- infrastructure
- deployment artifacts
- documentation
- diagrams
- database objects
- tests

Everything included in the delivery package must be supported by repository evidence.

---

# Implementation Verification

Review:

- actual source diff
- implemented behavior
- validation evidence
- executed tests
- CI results
- quality reports

Never report work that has not been verified.

---

# Documentation Synchronization

Determine whether updates are required for:

- README
- DESIGN.md
- ARCHITECTURE.md
- ADR
- API specifications
- OpenAPI
- diagrams
- runbooks
- deployment guides
- operational procedures
- troubleshooting guides

Update affected authoritative documentation or explain precisely why no update is required.

---

# Diagram Synchronization

Verify whether implementation changes affect:

- sequence diagrams
- component diagrams
- deployment diagrams
- data-flow diagrams
- state diagrams
- ER diagrams

Update diagrams only when implementation changes alter documented behavior.

---

# Architecture Synchronization

Determine whether architectural decisions changed.

If yes:

- update ADR
- update architecture documentation
- explain rationale

Otherwise provide a no-change justification.

---

# Testing Synchronization

Summarize:

- unit tests
- integration tests
- contract tests
- regression tests
- performance tests

Include:

- executed commands
- CI evidence
- skipped tests
- manual validation

Do not claim tests passed unless verified.

---

# Quality Gate Synchronization

Complete:

```
.ai/core/quality-gates.md
```

Include:

- gate
- status
- supporting evidence

Allowed statuses:

- PASSED
- FAILED
- NOT_APPLICABLE
- NOT_RUN

---

# Quality Review

Complete:

```
.ai/templates/code-quality-review.md
```

Include:

- detected technology stack
- detected platform
- selected quality profiles
- review evidence
- remaining risks

---

# Release Readiness

Determine:

- Ready for Merge
- Ready for Release
- Requires Additional Review
- Blocked

Justify the recommendation.

---

# PR / MR Preparation

Prepare a review-ready summary including:

- implementation summary
- business impact
- technical impact
- affected modules
- migration impact
- deployment considerations
- rollback considerations
- testing evidence
- documentation updates
- quality gate status
- remaining risks

Base every statement on repository evidence.

---

# Work Item Synchronization

Determine:

- affected Jira stories
- Azure DevOps work items
- GitHub issues
- GitLab issues

Generate update content.

Never claim external systems were updated unless verified.

If no approved connector exists, produce reviewable text only.

---

# Memory Governance

Evaluate:

```
.ai/core/memory-policy.md
```

Identify reusable knowledge candidates.

If none exist, explicitly report:

```
None
```

Never store or retrieve memory unless permitted by:

```
.ai/guards/memory-governance.yaml
```

---

# Traceability

Ensure traceability between:

- approved implementation plan
- changed source files
- documentation
- diagrams
- tests
- quality gates
- work items

Missing traceability should be reported.

---

# Compliance

Verify:

- protected files
- approval requirements
- security requirements
- architectural approvals
- governance compliance

Document any outstanding approvals.

---

# Deliverables

Every delivery package should contain:

1. Executive Summary
2. Repository Evidence
3. Implementation Summary
4. Documentation Changes
5. Diagram Changes
6. Architecture Changes
7. Testing Evidence
8. Quality Gate Results
9. Code Quality Review
10. PR/MR Summary
11. Work Item Updates
12. Memory Candidates
13. Remaining Risks
14. Release Readiness
15. Compliance Verification

Separate:

- Verified Facts
- Assumptions
- Unknowns

Never fabricate evidence or claim external updates that cannot be verified.