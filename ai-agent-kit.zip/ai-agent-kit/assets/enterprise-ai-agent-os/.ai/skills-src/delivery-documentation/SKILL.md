---
name: delivery-documentation
description: Synchronize implementation evidence with docs, specs, diagrams, PR/MR descriptions, and work-item handoff. Use near completion or PR/MR preparation; do not fabricate evidence.
---

# Delivery Documentation

Before delivery analysis, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Use CodeGraph/CocoIndex evidence to connect changed paths, impact, docs/specs/diagrams, tests, and completion artifacts.

## Required Checks

1. Inspect the actual diff and validation evidence.
2. Determine docs, specs, diagrams, runbooks, ADRs, API contracts, and work items affected.
3. Update affected authoritative documents or provide a specific no-change rationale.
4. Prepare PR/MR evidence using actual changed files and test results.
5. Complete quality gates from `.ai/core/quality-gates.md` with status and evidence.
6. Identify memory candidates under `.ai/core/memory-policy.md`, or state `None`.
7. Identify Jira/work-item update content and whether an approved connector exists.

## Rules

- Do not claim external systems were updated unless verified.
- Do not use generic placeholders when evidence is available.
- Include approved plan reference and compliance for protected changes.
- Do not store or retrieve memory unless `.ai/guards/memory-governance.yaml` allows it.
