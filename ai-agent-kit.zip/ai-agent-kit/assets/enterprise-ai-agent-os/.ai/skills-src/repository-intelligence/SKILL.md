---
name: repository-intelligence
description: Require and use CodeGraph plus CocoIndex before repository brainstorming, planning, impact analysis, review, QA analysis, documentation analysis, or implementation. Use when starting any repo task, assigning subagents, investigating code, producing a change-impact plan, reviewing a diff, validating QA risk, or preparing docs in this repository.
---

# Repository Intelligence

Run the gate before repository work:

```bash
python .ai/scripts/check-repository-intelligence.py --refresh-if-stale
```

If the result is `BLOCKED`, stop application work. Troubleshoot CodeGraph/CocoIndex only, or report the exact manual commands from the gate output.

## Retrieval Order

1. Query CodeGraph first for structural evidence: architecture, modules, symbols, callers/callees, dependency paths, APIs, database access, event producers/consumers, jobs, schedulers, and blast radius.
2. Query CocoIndex second for semantic evidence: business terminology, requirements, specs, ADRs, runbooks, contracts, test scenarios, release notes, and similar implementations.
3. Open only the most relevant paths and sections returned by the indexes.
4. Verify critical behavior against source code.
5. Expand direct file reading only when indexed evidence is stale, incomplete, unsupported, or line-level proof is required.

## Shared Brief

For multi-agent work, create `.ai/templates/repository-intelligence-brief.md` content before delegating. Include modules, entry points, call paths, classes/functions, data stores, integrations, specs, tests, impact areas, source paths, assumptions, and unknowns.

Subagents must reuse the shared brief and query CodeGraph/CocoIndex only for role-specific gaps.

## Existing-System Changes

The required sequence is:

```text
Repository Intelligence Gate
Indexed analysis
Multi-agent brainstorming
Impact assessment
Detailed implementation plan
Human team review and approval
Focused implementation
Index refresh
Independent review and QA
```

Do not edit protected application code before explicit approval evidence exists. After implementation, compare the actual diff to approved scope, query CodeGraph for changed-symbol impact, refresh both indexes, and stop for renewed approval if scope materially expands.
