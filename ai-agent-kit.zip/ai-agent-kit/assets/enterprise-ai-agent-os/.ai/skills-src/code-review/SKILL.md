---
name: code-review
description: Review code changes as a senior production engineer. Use for PRs, branch diffs, working-tree reviews, and design-risk reviews; avoid style-only noise.
---

# Code Review

Before review, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Use CodeGraph for changed-symbol impact and CocoIndex for related specs/docs/tests before opening only relevant source and diff sections.

Prioritize findings:

1. Correctness
2. Security
3. Data integrity
4. Concurrency and transaction behavior
5. Backward compatibility
6. Reliability and failure handling
7. Performance
8. Observability
9. Testing
10. Quality gate evidence
11. Memory governance
12. Maintainability

Each finding must include:

- Severity
- Location
- Problem
- Production impact
- Reproduction or evidence
- Recommended correction

Do not report purely stylistic preferences unless they materially affect maintainability or hide a real correctness issue.

Also report missing tests, quality-gate gaps, memory-governance violations, deployment risks, migration risks, rollback concerns, and areas reviewed with no issue found.
