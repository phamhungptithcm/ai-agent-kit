---
name: code-review
description: Perform a comprehensive production-grade engineering review of pull requests, branch diffs, working-tree changes, or design modifications using repository evidence. Focus on correctness, production risk, architectural integrity, and merge readiness rather than stylistic preferences.
---

# Code Review

## Purpose

Review changes as an experienced production engineer.

The objective is to identify issues that could affect:

- correctness
- production stability
- security
- scalability
- maintainability
- backward compatibility
- operational safety

Avoid stylistic feedback unless it materially affects correctness or long-term maintainability.

---

# Repository Intelligence Gate (Required)

Before reviewing:

1. Execute the Repository Intelligence Gate.
2. Use the `repository-intelligence` skill.
3. Discover repository evidence from:

- CodeGraph
- CocoIndex
- ADRs
- RFCs
- DESIGN.md
- ARCHITECTURE.md
- Existing diagrams
- Recent commits
- CI configuration
- Existing tests

Use:

- CodeGraph for changed symbols, dependency impact, callers, and consumers.
- CocoIndex for related documentation, specifications, architecture decisions, and historical context.

Open only source files required to verify findings.

---

# Quality Profile Detection

Execute the `code-quality-review` skill.

Automatically determine:

- language
- language version
- runtime
- framework
- platform
- application type
- domain
- tooling

Load:

- `.ai/quality-profiles/universal.yaml`
- applicable language profiles
- platform profiles
- cross-cutting profiles

Document every profile used during review.

---

# Review Scope

Determine:

- changed files
- changed symbols
- impacted modules
- callers
- downstream consumers
- APIs
- persistence
- infrastructure
- deployment artifacts
- documentation
- tests

Review the entire change boundary, not only modified lines.

---

# Review Priorities

Review in the following order.

## 1. Correctness

Verify:

- business logic
- edge cases
- validation
- error handling
- null safety
- invariants

---

## 2. Security

Review:

- authentication
- authorization
- secrets
- encryption
- injection risks
- input validation
- output encoding
- sensitive logging
- PII
- PCI

---

## 3. Data Integrity

Review:

- persistence
- transactions
- consistency
- migrations
- optimistic locking
- retries
- duplicate processing

---

## 4. Concurrency

Review:

- thread safety
- async behavior
- race conditions
- deadlocks
- scheduling
- cancellation
- synchronization

---

## 5. Backward Compatibility

Verify:

- APIs
- events
- serialization
- schemas
- database compatibility
- configuration compatibility

---

## 6. Reliability

Review:

- retries
- circuit breakers
- timeout handling
- graceful degradation
- fallback behavior
- recovery

---

## 7. Performance

Evaluate:

- algorithms
- allocations
- query plans
- N+1 queries
- batching
- payload size
- cache behavior
- network usage

---

## 8. Observability

Verify:

- logging
- metrics
- tracing
- correlation IDs
- operational diagnostics
- alerts

---

## 9. Testing

Review:

- unit tests
- integration tests
- contract tests
- regression tests
- performance tests

Determine whether important behaviors remain untested.

---

## 10. Quality Gates

Verify compliance with all loaded quality profiles.

Identify:

- missing evidence
- skipped validation
- unsupported assumptions

---

## 11. Language Review

Review:

- version compatibility
- deprecated APIs
- framework conventions
- compiler/runtime concerns

---

## 12. Platform Review

Verify platform-specific best practices.

Examples:

- Backend
- Web
- Mobile
- Desktop
- DevOps
- Infrastructure

---

## 13. Resource Lifecycle

Inspect:

- memory
- streams
- sockets
- database connections
- transactions
- listeners
- timers
- caches
- thread pools

---

## 14. Memory Governance

Review:

- heap retention
- cache growth
- static references
- object lifetime
- allocation pressure

---

## 15. Maintainability

Review:

- cohesion
- coupling
- abstraction
- ownership
- duplication
- readability
- complexity

---

# Finding Requirements

Every finding must include:

## Severity

- Critical
- High
- Medium
- Low
- Informational

---

## Location

Precise:

- file
- class
- function
- SQL
- configuration

---

## Problem

Describe the issue.

---

## Production Impact

Explain:

- operational impact
- business impact
- customer impact

---

## Evidence

Provide:

- repository evidence
- code evidence
- runtime reasoning

Do not speculate.

---

## Recommendation

Recommend the smallest safe correction.

---

# Additional Review

Also report:

- detected technology stack
- detected platform
- selected quality profiles
- missing tests
- architecture risks
- deployment risks
- migration risks
- rollback risks
- documentation gaps
- observability gaps
- quality gate failures
- memory governance issues

---

# Positive Findings

Explicitly identify areas reviewed with no issues.

Examples:

- transaction handling verified
- API compatibility verified
- retry logic verified
- authorization verified

---

# Merge Readiness

Conclude with exactly one recommendation:

- APPROVED
- APPROVED WITH MINOR COMMENTS
- CHANGES REQUESTED
- BLOCKED

Critical findings automatically result in **BLOCKED**.

High-risk issues generally require **CHANGES REQUESTED** unless strong mitigating evidence exists.

---

# Deliverables

Every review should contain:

1. Executive Summary
2. Repository Evidence
3. Review Scope
4. Detected Stack
5. Selected Quality Profiles
6. Findings by Severity
7. Positive Findings
8. Missing Tests
9. Documentation Gaps
10. Deployment Risks
11. Rollback Risks
12. Remaining Risks
13. Merge Readiness

Clearly separate:

- Verified Findings
- Assumptions
- Unknowns

Never report assumptions as verified defects.