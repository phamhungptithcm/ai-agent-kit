---
name: production-incident
description: Investigate production-like incidents with evidence. Use for outages, degraded behavior, failed deployments, urgent operational anomalies, or incident postmortems.
---

# Production Incident

Before incident codebase analysis, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Use CodeGraph for services/jobs/dependencies/blast radius and CocoIndex for runbooks, deployment notes, incident docs, specs, tests, and rollback procedures.

## Required Process

1. Establish timeline and observed impact.
2. Gather logs, metrics, traces, release changes, config changes, data samples, and operator actions.
3. Identify the first incorrect state.
4. Distinguish root cause from contributing factors.
5. Propose mitigation, permanent correction, validation, and prevention.
6. Document rollback, communication, and unresolved evidence gaps.

## Rules

- Do not invent evidence.
- Do not claim certainty unsupported by logs, metrics, traces, data, or reproducible behavior.
- Do not access production systems or data without explicit authorization and an approved procedure.
- Treat incident response that touches production data, secrets, financial state, IAM, or security controls as high or critical risk.
