---
name: security-review
description: Review code, design, infrastructure, and delivery changes for authentication, authorization, secrets, privacy, injection, supply-chain, and abuse risks.
---

# Security Review

Use this skill for security-sensitive changes or as an independent review layer.

## Required Review

- Authentication and authorization are enforced server-side.
- Object-level, tenant, role, and permission boundaries are preserved.
- Secrets, tokens, credentials, PII, PHI, PCI, and regulated data are not exposed in code, logs, telemetry, browser storage, artifacts, or prompts.
- Input validation, output encoding, injection prevention, deserialization safety, and file/path handling are reviewed.
- API, webhook, event, and background-job abuse paths are reviewed.
- Dependency, container, CI/CD, and supply-chain risks are reviewed.
- Audit, alerting, and incident response requirements are covered.

## Output

Lead with findings by severity. Include location, exploit or abuse scenario, production impact, evidence, recommended correction, and residual risk. Avoid generic security advice without a concrete path in this repository.
