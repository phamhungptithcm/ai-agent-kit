---
name: jira-completion-package
description: Prepare a Jira-ready completion comment with RCA, solution, MR/PR evidence, validation, docs/diagrams, demo package, deployment, rollback, and risks. Do not update Jira unless an approved connector and verified permission exist.
---

# Jira Completion Package

Before preparing completion content, run the Repository Intelligence Gate when the package summarizes repository work. Use CodeGraph/CocoIndex evidence for changed paths, affected components, docs/specs/tests, and validation traceability.

## Required Content

- Repository intelligence gate status.
- RCA or planned-change rationale.
- Solution and impacted components.
- Verified MR/PR link and actual state, or state that none exists.
- Acceptance criteria status with evidence.
- Validation commands/procedures and actual results.
- Documentation, specification, and diagram links or no-change rationale.
- Demo package paths or source outlines.
- Manual screenshot placeholder table.
- Deployment and rollback summary.
- Risks, blockers, follow-up work, and owners when known.

## Jira Update Rule

Do not transition or update Jira unless issue key, workflow, permission, approved integration, and successful response are verified. Otherwise produce copy-ready text only.
