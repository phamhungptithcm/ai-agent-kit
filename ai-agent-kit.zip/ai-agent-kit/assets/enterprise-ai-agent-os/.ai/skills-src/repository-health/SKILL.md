---
name: repository-health
description: Assess repository maintainability, policy drift, tooling health, test reliability, dependency risk, documentation freshness, and AI-agent configuration health.
---

# Repository Health

Use this skill for periodic technical health checks or before major team rollout.

## Required Work

1. Run repository intelligence and configuration validators.
2. Review build/test commands, CI status expectations, generated skill drift, prompt catalog coverage, guards, evals, and docs.
3. Review dependency hygiene, stale tooling, security policy, test reliability, flaky areas, and maintainability hotspots.
4. Review architecture docs, ADRs, repository map, ownership, memory policy, and quality profiles for drift.
5. Identify low-cost fixes separately from larger refactors.

## Output

Report health score, blockers, drift, stale docs, missing tests, dependency/tooling risks, recommended fixes, owners, and cadence for follow-up.
