---
name: fix-bug
description: Diagnose and fix a defect by finding the first incorrect state. Use for runtime errors, failed tests, regressions, and unexpected behavior; do not use for superficial symptom hiding.
---

# Fix Bug

Before investigating, run the Repository Intelligence Gate and use the `repository-intelligence` skill. Use CodeGraph for the failing flow and regression surface, and CocoIndex for related specs, tests, docs, similar failures, and historical notes.

## Required Investigation

1. Gather indexed evidence, then reproduce when feasible.
2. Separate indexed facts, source-code verified facts, and assumptions.
3. Reconstruct the execution path.
4. Identify the first incorrect state.
5. Classify cause across data, code, configuration, dependency, concurrency, and infrastructure.
6. Identify root cause and contributing factors.
7. For existing-system code changes, produce a change-impact plan and wait for explicit approval before editing protected files.

## Prohibited Fixes

- Do not hide the error.
- Do not add generic retries without proving idempotency and retry safety.
- Do not add null checks without explaining why the null state exists.
- Do not swallow exceptions or remove failure context.
- Do not perform unrelated refactoring.

## Completion

Implement the smallest approved safe fix, add a regression test when feasible, refresh CodeGraph/CocoIndex indexes, run focused validation, update docs/specs/diagrams or provide no-change rationale, and report root cause, behavior change, approved-plan compliance, evidence, residual risk, and rollback.
