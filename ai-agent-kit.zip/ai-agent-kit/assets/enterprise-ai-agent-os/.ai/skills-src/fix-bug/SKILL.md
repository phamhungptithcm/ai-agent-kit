---
name: fix-bug
description: Perform evidence-driven root cause analysis and implement the smallest safe fix for defects, regressions, runtime failures, failed tests, or unexpected behavior. Focus on eliminating the first incorrect state rather than masking symptoms.
---

# Fix Bug

## Purpose

Diagnose and permanently resolve defects by identifying and correcting the **first incorrect state**.

Prioritize correctness, root-cause elimination, regression prevention, and production safety.

Never implement symptom-only fixes.

---

# Repository Intelligence Gate (Required)

Before investigation:

1. Execute the Repository Intelligence Gate.
2. Use the `repository-intelligence` skill.
3. Collect evidence from:

- CodeGraph
- CocoIndex
- ADRs
- RFCs
- DESIGN.md
- ARCHITECTURE.md
- Existing tests
- Previous bug fixes
- Known incidents
- Runbooks
- Recent commits

Use:

- CodeGraph to reconstruct execution flow, dependency graph, callers, consumers, and regression surface.
- CocoIndex to locate specifications, historical bugs, documentation, design intent, and operational knowledge.

Repository evidence guides investigation but never replaces source-code verification.

---

# Investigation Workflow

## Step 1 — Gather Evidence

Collect:

- failing behavior
- logs
- stack traces
- test failures
- user reports
- monitoring
- metrics
- traces
- repository evidence

Reproduce the issue whenever practical.

---

## Step 2 — Classify Evidence

Separate information into:

### Verified Repository Facts

Supported by repository evidence.

### Verified Source-Code Facts

Confirmed by implementation.

### Runtime Evidence

Observed during execution.

### Assumptions

Clearly marked assumptions.

Never mix assumptions with verified facts.

---

## Step 3 — Reconstruct Execution Path

Trace:

- entry point
- request flow
- services
- repositories
- database
- messaging
- external APIs
- schedulers
- caches
- async boundaries
- error handling

Identify state transitions throughout execution.

---

## Step 4 — Find the First Incorrect State

Locate the earliest point where the system deviates from expected behavior.

Distinguish between:

- Trigger
- Symptom
- First Incorrect State
- Root Cause
- Contributing Factors

Never stop at the visible failure.

---

## Step 5 — Root Cause Classification

Classify the defect.

Examples:

- Business logic
- Data
- Configuration
- Deployment
- Infrastructure
- Concurrency
- Transaction
- Dependency
- Integration
- Serialization
- Resource lifecycle
- Security
- Performance

Assign a confidence level:

- High
- Medium
- Low

Support conclusions with evidence.

---

# Impact Analysis

Before proposing a fix:

Determine:

- affected modules
- callers
- downstream consumers
- APIs
- persistence
- configuration
- deployment
- documentation
- tests

Identify the regression surface.

---

# Quality Review

Execute:

```
code-quality-review
```

Automatically detect:

- language
- framework
- runtime
- platform
- quality profiles

Apply all matching profiles.

---

# Existing System Changes

If modifying existing production code:

Generate a:

```
change-impact-plan
```

Implementation must not begin until explicit approval exists for protected changes.

---

# Fix Strategy

Recommend the **smallest safe change** that removes the root cause.

Avoid unnecessary redesign or unrelated refactoring.

---

# Prohibited Fixes

Never:

- hide failures
- suppress exceptions
- swallow errors
- remove diagnostics
- weaken validation
- add generic retries without proving retry safety
- add null checks without explaining the invalid state
- disable tests to make the issue disappear
- perform unrelated cleanup

---

# Regression Prevention

Prevent recurrence through:

- regression tests
- validation improvements
- stronger invariants
- monitoring
- logging
- alerts
- documentation
- operational guidance

Regression prevention is broader than adding a single test.

---

# Validation

Verify:

- original defect resolved
- no behavior regressions
- compatibility preserved
- performance acceptable
- quality gates satisfied

Run targeted validation using repository commands whenever possible.

---

# Documentation

Determine whether updates are required for:

- DESIGN.md
- ARCHITECTURE.md
- ADR
- diagrams
- runbooks
- troubleshooting guides

If no updates are needed, provide a clear rationale.

---

# Repository Synchronization

Refresh CodeGraph and CocoIndex indexes **only if** implementation changes repository structure, APIs, symbols, or documentation relied upon by indexing.

---

# Deliverables

Every bug investigation should contain:

1. Executive Summary
2. Repository Evidence
3. Runtime Evidence
4. Reproduction Steps
5. Execution Path
6. Trigger
7. Symptom
8. First Incorrect State
9. Root Cause
10. Contributing Factors
11. Impact Analysis
12. Proposed Fix
13. Validation Results
14. Regression Prevention
15. Documentation Impact
16. Remaining Risks
17. Rollback Strategy

Separate:

- Verified Facts
- Runtime Evidence
- Assumptions
- Unknowns

Never report assumptions as confirmed root causes.