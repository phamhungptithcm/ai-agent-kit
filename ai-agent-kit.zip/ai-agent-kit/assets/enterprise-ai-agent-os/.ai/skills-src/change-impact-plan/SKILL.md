---
name: change-impact-plan
description: Produce a reviewed implementation plan before changing existing systems. Use for existing application code, functions, database flows, runtime config, infrastructure, public contracts, or behavior-changing tests; do not edit protected files while using this skill.
---

# Change Impact Plan

Use this skill before implementation.

First run the Repository Intelligence Gate and use the `repository-intelligence` skill. The plan must include CodeGraph structural impact, CocoIndex semantic/documentation evidence, and source-code verified facts.

## Required Work

1. Query CodeGraph and CocoIndex before direct file reading.
2. Inspect current implementation, tests, configuration, docs, specifications, diagrams, recent related changes, and linked work item when needed to verify indexed evidence.
3. Trace the current end-to-end flow, including callers, consumers, persistence, integrations, error paths, retries, jobs, and operational behavior.
4. Identify verified root cause or requirement gap.
5. Identify exact expected modules, classes, functions, SQL, contracts, configuration, tests, documents, and diagrams to change.
6. Define the change area boundary, impact boundary, files explicitly approved for change, areas requiring developer review before touching, and reason no other area is changed.
7. Analyze callers, consumers, data, integrations, security, performance, concurrency, compatibility, operations, deployment, rollback, and preserved behavior.
8. Propose the smallest safe solution focused only on the issue.
9. Document alternatives, trade-offs, tests, regression strategy, assumptions, unknowns, and risks.

## Stop Condition

Stop after presenting the plan and request developer-team approval. Do not implement until explicit approval evidence exists.

If implementation later requires material scope beyond the approved plan, stop and request approval for a delta-impact plan.
