# Database Rules

- Avoid `SELECT *` in production queries.
- Use bounded queries, pagination, and explicit ordering where result size or order matters.
- Review indexes and query plans for material query changes.
- Make migrations backward-compatible when rolling deployment is possible.
- Separate schema migration from destructive cleanup.
- Include data validation and rollback strategy.
- Never run production datafixes autonomously.
- Treat financial, ledger, reconciliation, regulated, and sensitive data as high or critical risk until proven otherwise.
- Coordinate database diff scripts with existing Jenkins/GitLab database flows.
- Do not call `repository.save()` inside large loops.
- Use batch update, bulk persistence, or set-based SQL for large transactions.
- If loop persistence is unavoidable, document transaction size, flush/clear behavior, locking risk, retry/idempotency behavior, and approval evidence.
