# Diagramming Rules

- Treat diagrams as authoritative documentation when they explain architecture, data flow, sequence, state, class relationships, integrations, or deployment behavior.
- Use text-based diagram source such as Mermaid wherever practical.
- Store diagram source with documentation, not as an opaque screenshot.
- Update affected diagrams in the same change set as the behavior change, or provide a specific no-change rationale.
- Choose diagram type by purpose:
  - Sequence: request/response flow, retries, async interactions, handoffs.
  - Component: service/module boundaries and dependencies.
  - Class: important object relationships or extension points.
  - State: lifecycle/status transitions.
  - Data-flow: movement of sensitive, financial, or operational data.
  - ER: schema/entity relationships.
- Do not create diagrams that claim unverified production topology, ownership, or integrations.
- Link diagrams from the relevant design document, runbook, README, or API/spec document.
