# Testing Rules

- Add a regression test for a bug fix when feasible.
- Cover happy path, validation failures, authorization failures, business-rule failures, and important edge cases in proportion to risk.
- Use integration or contract tests for changed boundaries.
- Avoid tests that only mirror implementation details.
- Keep tests deterministic and isolated from production systems.
- Do not weaken or delete tests to make a change pass without explaining and justifying the behavior change.
- Report skipped or unavailable tests explicitly.
- Do not claim a test passed unless it actually ran and the result was observed.
