# Delivery Traceability Rules

- Keep implementation, documentation, specifications, diagrams, MR/PR evidence, and work items synchronized.
- Every completed ticket should have a copy-ready Jira completion package unless the task has no work item.
- Jira updates must be performed only through an approved, authenticated, authorized integration with a verified issue key and successful response.
- If no approved Jira connector or permission is available, produce copy-ready Jira text and state that no Jira update was performed.
- MR/PR preparation must inspect the actual diff and use evidence from files, tests, docs, specs, diagrams, and validation output.
- Do not use generic placeholders when evidence is available.
- Do not claim a PR/MR, Jira update, screenshot, PPTX, XLSX, diagram, or documentation update happened without verifiable evidence.
- Demo-required changes must include screenshot placeholders that state exactly what a human must capture.
