# Git And PR Rules

- Preserve user changes. Do not revert or overwrite unrelated work.
- Check `git status --short --branch` before and after edits.
- Do not run destructive commands such as `git reset --hard`, `git clean`, or force checkout unless explicitly requested.
- Do not push, tag, release, or modify protected branches without explicit human instruction.
- Keep commits and PRs scoped to the task.
- PR descriptions should include summary, business outcome, files changed, tests, security/data/performance impact, deployment notes, rollback, and remaining risk.
- `.github/workflows/**`, production deployment files, IAM, Terraform, Kubernetes production config, and CODEOWNERS require explicit task scope and human approval.
