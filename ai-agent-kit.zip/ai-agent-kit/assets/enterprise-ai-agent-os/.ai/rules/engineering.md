# Engineering Rules

- Prefer the smallest safe change.
- Preserve existing behavior unless the task explicitly changes it.
- Follow established repository patterns before introducing new abstractions.
- Avoid broad refactoring inside scoped bug fixes or feature work.
- Do not rename public contracts, database objects, package names, or API fields without impact analysis.
- Do not modify generated files directly. Update the source and regenerate.
- Do not swallow exceptions.
- Do not add generic retries without proving idempotency and retry safety.
- Do not add a null check without identifying why the invalid or null state exists.
- Preserve original failure context while preventing sensitive-data leakage.
- Define timeout, retry, circuit-breaker, and fallback behavior for external calls where applicable.
