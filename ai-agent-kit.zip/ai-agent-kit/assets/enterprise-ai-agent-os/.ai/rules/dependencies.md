# Dependency Rules

- Do not add dependencies without rationale, maintenance review, license review, and security review.
- Prefer existing repository dependencies and platform capabilities.
- Pin or constrain versions according to local build conventions.
- Avoid network downloads or install scripts as part of agent setup unless explicitly approved.
- Do not introduce dependencies that require production credentials, broad filesystem access, or unreviewed external services.
- Document dependency impact, transitive risk, and rollback.
