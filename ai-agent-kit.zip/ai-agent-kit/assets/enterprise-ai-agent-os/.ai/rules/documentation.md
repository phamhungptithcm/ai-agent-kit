# Documentation Rules

- Update documentation when behavior, commands, workflows, operational procedures, public contracts, or risk assumptions change.
- Mark unresolved project context with `TODO(owner): ...`.
- Do not invent business rules, ownership, environments, or production procedures.
- Keep root instruction files compact and route to shared policy.
- Prefer links to canonical `.ai/` files over duplicating full policy.
- Attribute adapted third-party content and respect licenses.
- Do not vendor external reference repositories into this repository.
