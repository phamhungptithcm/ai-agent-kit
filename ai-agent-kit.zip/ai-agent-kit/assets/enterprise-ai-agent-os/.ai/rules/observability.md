# Observability Rules

- Use structured logs where the local framework supports them.
- Preserve correlation, request, trace, job, or transaction identifiers.
- Do not log sensitive data.
- Add metrics or operational evidence for production-significant flows.
- Define how an operator can verify success after deployment.
- Include alerting, dashboard, or runbook implications for high-risk behavior changes.
- Capture enough context to troubleshoot without exposing secrets or PII.
