# API Design Rules

- Use explicit request and response contracts.
- Do not expose persistence entities directly.
- Validate input at system boundaries.
- Use stable error contracts and avoid leaking internal exception details.
- Analyze backward compatibility and consumers before changing public or cross-module contracts.
- Include authorization, rate-limit, idempotency, and audit implications in API changes.
- Version or stage breaking changes with migration guidance.
- Document changed API behavior where consumers need it.
