# Fix Bug Workflow

Use this workflow for defects, regressions, failed tests, incidents with known code symptoms, or unexpected runtime behavior.

1. Run the Repository Intelligence Gate and stop if it is blocked.
2. Use CodeGraph to locate the failing flow, callers, callees, impacted symbols, and regression surface.
3. Use CocoIndex to find related specs, test scenarios, similar failures, docs, and historical notes.
4. Gather evidence and reproduce when feasible.
5. Separate indexed facts, source-code verified facts, and assumptions.
6. Trace the execution path to the first incorrect state, not only the final error.
7. Classify likely cause across data, code, configuration, dependency, concurrency, and infrastructure.
8. Identify root cause and contributing factors.
9. Propose the smallest safe fix.
10. Add a regression test when feasible.
11. Refresh CodeGraph/CocoIndex indexes after approved changes.
12. Validate the fix and relevant adjacent behavior.

Do not hide symptoms with generic retries, unexplained null checks, broad catches, or unrelated refactoring.
