# Implement Feature Workflow

Use this workflow after the business outcome, acceptance criteria, and scope are clear.

1. Run the Repository Intelligence Gate and stop if it is blocked.
2. Load applicable rules, context, approved plan, and repository intelligence brief.
3. Query CodeGraph for changed-symbol impact and exact files/functions expected to change.
4. Query CocoIndex for similar existing implementations, specs, tests, docs, and reusable patterns.
5. Confirm contracts, data ownership, authorization, compatibility, and operational impact.
6. Verify explicit approval evidence for existing-system changes before editing protected files.
7. Implement the smallest safe change inside the approved scope.
8. Add or update tests for expected behavior and important failure paths.
9. Update documentation or operational notes when needed.
10. Run focused validation and complete `.ai/core/quality-gates.md` with status and evidence.
11. Compare actual diff to approved scope, refresh CodeGraph/CocoIndex indexes, and re-run the gate.
12. Review security, data, performance, concurrency, deployment, and rollback.
13. Report memory candidates under `.ai/core/memory-policy.md`, or state `None`.

Do not add dependencies, broaden scope, or change public contracts without explicit rationale and review.
